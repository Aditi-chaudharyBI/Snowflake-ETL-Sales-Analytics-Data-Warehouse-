# Azure Data Factory

Import `pipeline_sales_ingest.json` and `trigger_daily.json` into ADF Studio (or commit to your ADF Git repo).

Create first:
1. **LS_Snowflake** – Snowflake linked service (account, warehouse `ETL_WH`, database `SALES_DW`, role `SYSADMIN`; store the password in Key Vault).
2. **LS_BlobStorage** – Azure Blob/ADLS linked service.
3. **DS_Blob_Sales_Prepared** – DelimitedText dataset (header row = true) on container `sales`, folder `prepared`.
4. **DS_Snowflake_RAW_SALES_RAW** – Snowflake dataset on `RAW.SALES_RAW`.

Flow: Copy (Blob -> RAW) -> `CALL ETL.SP_LOAD_STAGING()` -> `CALL ETL.SP_LOAD_ANALYTICS()`.
Re-runs are safe: each stored procedure only processes rows newer than its watermark.
Sink column mapping: map the 17 CSV columns plus `SOURCE_FILE`; `LOADED_AT` uses the table default.
