```mermaid
flowchart LR
  A[CSV sales files] --> B[Python: prepare_source.py<br/>profile, dedupe, column contract]
  B --> C[Azure Blob Storage]
  C -->|ADF Copy activity| D[(RAW.SALES_RAW)]
  B -.->|local alternative: PUT + COPY| D
  D -->|SP_LOAD_STAGING<br/>cleanse, dedupe, MERGE| E[(STAGING.STG_SALES)]
  D -->|invalid rows| R[(STG_SALES_REJECTS)]
  E -->|SP_LOAD_ANALYTICS<br/>MERGE dims + fact| F[(ANALYTICS star schema)]
  F --> G[Views] --> H[Power BI / Tableau]
```

```mermaid
erDiagram
  FACT_SALES }o--|| DIM_DATE : date_key
  FACT_SALES }o--|| DIM_CUSTOMER : customer_key
  FACT_SALES }o--|| DIM_PRODUCT : product_key
  FACT_SALES }o--|| DIM_REGION : region_key
  FACT_SALES {
    number sales_key PK
    varchar order_id
    number order_line_id
    number quantity
    number unit_price
    number discount_pct
    number gross_amount
    number net_amount
    varchar sales_channel
  }
  DIM_DATE { number date_key PK }
  DIM_CUSTOMER { number customer_key PK }
  DIM_PRODUCT { number product_key PK }
  DIM_REGION { number region_key PK }
```
