"""Orchestrate: PUT prepared files -> COPY INTO RAW -> RAW->STAGING -> STAGING->ANALYTICS -> validate.

Usage:  python python/load_to_snowflake.py
Env  :  see .env.example
Exit 0 if every validation check passes, 1 otherwise.
"""
import os
import sys
from pathlib import Path

import snowflake.connector
from dotenv import load_dotenv

from common import PREPARED_DIR, RAW_DIR, ROOT, file_hash, load_state, save_state

SQL_DIR = ROOT / "sql"


def connect():
    load_dotenv(ROOT / ".env")
    return snowflake.connector.connect(
        account=os.environ["SNOWFLAKE_ACCOUNT"],
        user=os.environ["SNOWFLAKE_USER"],
        password=os.environ["SNOWFLAKE_PASSWORD"],
        role=os.getenv("SNOWFLAKE_ROLE", "SYSADMIN"),
        warehouse=os.getenv("SNOWFLAKE_WAREHOUSE", "ETL_WH"),
        database=os.getenv("SNOWFLAKE_DATABASE", "SALES_DW"),
    )


def run_sql_file(cur, name: str):
    sql = (SQL_DIR / name).read_text().strip().rstrip(";")
    cur.execute(sql)
    return cur.fetchall()


def main() -> int:
    state = load_state()
    pending = [p for p in sorted(PREPARED_DIR.glob("*.csv"))
               if state.get(p.name) != file_hash(RAW_DIR / p.name)]
    if not pending:
        print("Nothing new to load.")
        return 0

    conn = connect()
    cur = conn.cursor()
    try:
        for p in pending:
            cur.execute(f"PUT 'file://{p.as_posix()}' @RAW.SALES_STAGE AUTO_COMPRESS=TRUE OVERWRITE=TRUE")
            print(f"[PUT ] {p.name}")

        copy_rows = run_sql_file(cur, "05_copy_into_raw.sql")
        for r in copy_rows:
            print(f"[COPY] {r}")

        cur.execute("CALL ETL.SP_LOAD_STAGING()")
        print("[ETL ]", cur.fetchone()[0])
        cur.execute("CALL ETL.SP_LOAD_ANALYTICS()")
        print("[ETL ]", cur.fetchone()[0])

        results = run_sql_file(cur, "06_data_validation.sql")
        failed = [r for r in results if r[3] == "FAIL"]
        print("\nValidation results")
        for check, expected, actual, status in results:
            print(f"  [{status}] {check}  (expected={expected}, actual={actual})")

        if failed:
            print(f"\n{len(failed)} validation check(s) failed. Files NOT marked as loaded.")
            return 1

        for p in pending:
            state[p.name] = file_hash(RAW_DIR / p.name)
        save_state(state)
        print("\nAll checks passed.")
        return 0
    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    sys.exit(main())
