"""Shared helpers: paths, column contract, file-hash state for incremental loads."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw"
PREPARED_DIR = ROOT / "data" / "prepared"
REPORT_DIR = ROOT / "reports"
STATE_FILE = ROOT / ".state" / "loaded_files.json"

COLUMNS = [
    "order_id", "order_line_id", "order_date", "customer_id", "customer_name", "email",
    "segment", "product_id", "product_name", "category", "unit_price", "quantity",
    "discount_pct", "region_code", "region_name", "country", "sales_channel",
]


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_state() -> dict:
    return json.loads(STATE_FILE.read_text()) if STATE_FILE.exists() else {}


def save_state(state: dict) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))
