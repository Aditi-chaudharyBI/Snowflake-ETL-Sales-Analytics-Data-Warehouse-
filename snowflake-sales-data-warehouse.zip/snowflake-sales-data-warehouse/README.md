# Snowflake ETL & Sales Analytics Data Warehouse

End-to-end batch pipeline that ingests messy sales CSVs into **Snowflake** through **RAW → STAGING → ANALYTICS** layers, models a **star schema**, loads incrementally, and validates source-to-target before BI reporting.

**Stack:** Snowflake · SQL (Snowflake Scripting) · Python (Pandas) · Azure Data Factory · Power BI / Tableau

## Architecture

```mermaid
flowchart LR
  A[CSV sales files] --> B[Python: prepare_source.py]
  B --> C[Azure Blob Storage]
  C -->|ADF Copy| D[(RAW)]
  B -.->|local: PUT + COPY| D
  D -->|SP_LOAD_STAGING| E[(STAGING)]
  D -->|rejects| R[(STG_SALES_REJECTS)]
  E -->|SP_LOAD_ANALYTICS| F[(ANALYTICS star schema)]
  F --> G[Views] --> H[Power BI / Tableau]
```

## Data model

| Table | Grain / purpose |
|---|---|
| `FACT_SALES` | One row per order line; `quantity`, `unit_price`, `discount_pct`, `gross_amount`, `net_amount` |
| `DIM_DATE` | Calendar 2023–2028 (year, quarter, month, weekday, weekend flag) |
| `DIM_CUSTOMER` | Customer attributes, surrogate `customer_key` (SCD Type 1) |
| `DIM_PRODUCT` | Product and category |
| `DIM_REGION` | Region and country |

ER diagram: [docs/architecture.md](docs/architecture.md)

## What each layer does

| Layer | Logic |
|---|---|
| **RAW** | Append-only, all `VARCHAR`, plus `SOURCE_FILE` and `LOADED_AT`. Loaded with `COPY INTO` (file-level idempotency). |
| **STAGING** | `TRIM/INITCAP/UPPER/LOWER` standardization, `TRY_TO_*` type casting, two date formats, `QUALIFY ROW_NUMBER()` deduplication, invalid rows routed to `STG_SALES_REJECTS` with a reason code, `MERGE` upsert. |
| **ANALYTICS** | Dimension `MERGE`s, surrogate-key lookups, fact `MERGE` on `(order_id, order_line_id)`. |

## Incremental loading

- **File level (Python):** SHA-256 of each raw file is stored in `.state/loaded_files.json`; unchanged files are skipped.
- **Row level (SQL):** `ETL.LOAD_WATERMARK` holds a watermark per hop (`RAW_TO_STG`, `STG_TO_DW`). Each procedure processes only rows with `LOADED_AT > watermark`, then advances it.
- **Late-arriving corrections:** batch 2 re-sends 40 order lines from batch 1 with changed quantities; `MERGE` updates them in place instead of duplicating.

## Data quality

| Stage | Checks |
|---|---|
| Pre-load (Pandas) | Column contract, blank rows, exact duplicates, blank IDs, non-numeric/non-positive quantity, JSON profile per file in `reports/` |
| Staging (SQL) | Missing keys, invalid date/price/quantity → `STG_SALES_REJECTS` |
| Post-load (`06_data_validation.sql`) | Duplicate keys, STG vs FACT row count, STG vs FACT net revenue, orphan dimension keys, null critical fields, discount range. Loader exits non-zero on any `FAIL`. |

## Project structure

```
├── sql/            01_setup … 07_reporting_views (run in order; 05/06 are run by the loader)
├── python/         generate_sales_data.py, prepare_source.py, load_to_snowflake.py, common.py
├── adf/            pipeline_sales_ingest.json, trigger_daily.json, setup notes
├── data/raw/       3 sample batches (~15K rows, intentionally dirty)
└── docs/           architecture + ER diagrams
```

## Run it

```bash
pip install -r requirements.txt
cp .env.example .env            # fill in Snowflake credentials

# 1. One-time: run sql/01 → 04 and 07 in a Snowsight worksheet (or SnowSQL)

# 2. (optional) regenerate sample data
python python/generate_sales_data.py

# 3. Prepare + load + transform + validate
python python/prepare_source.py
python python/load_to_snowflake.py
```

Re-run step 3 any time: unchanged files are skipped and watermarks make the SQL steps safe to repeat.

For the ADF path, see [adf/README.md](adf/README.md).

## Sample analytics queries

```sql
-- Monthly net revenue by category
SELECT MONTH_START, CATEGORY, SUM(NET_REVENUE) AS NET_REVENUE
FROM SALES_DW.ANALYTICS.VW_MONTHLY_SALES GROUP BY 1, 2 ORDER BY 1, 3 DESC;

-- Top 10 customers
SELECT * FROM SALES_DW.ANALYTICS.VW_CUSTOMER_RANKING WHERE REVENUE_RANK <= 10;

-- Reject reasons
SELECT REJECT_REASON, COUNT(*) FROM SALES_DW.STAGING.STG_SALES_REJECTS GROUP BY 1 ORDER BY 2 DESC;

-- Region x channel performance
SELECT REGION_NAME, SALES_CHANNEL, SUM(NET_AMOUNT) AS NET_REVENUE
FROM SALES_DW.ANALYTICS.VW_SALES_DETAIL GROUP BY 1, 2 ORDER BY 3 DESC;
```

## Author

Aditi Chaudhary · [LinkedIn](https://www.linkedin.com/in/aditi-chaudharydev/) · [GitHub](https://github.com/Aditi-chaudharyBI)
