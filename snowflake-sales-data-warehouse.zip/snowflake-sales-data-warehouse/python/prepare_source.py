"""Source-data preparation and pre-load data quality profiling (Pandas).

- Incremental: skips raw files whose SHA-256 is already recorded as loaded.
- Enforces the column contract (names lowercased/trimmed, fixed order) so COPY INTO is positional-safe.
- Drops fully blank rows, removes exact duplicate rows, and writes a JSON profile per file.
- Fails the file (no output written) if required columns are missing. Row-level cleansing
  and business-rule rejects happen in Snowflake (STAGING layer) so RAW keeps source fidelity.
"""
import json
import sys

import pandas as pd

from common import COLUMNS, PREPARED_DIR, RAW_DIR, REPORT_DIR, file_hash, load_state


def profile(df: pd.DataFrame) -> dict:
    qty = pd.to_numeric(df["quantity"], errors="coerce")
    price = pd.to_numeric(df["unit_price"], errors="coerce")
    return {
        "rows": int(len(df)),
        "blank_order_id": int((df["order_id"].str.strip() == "").sum()),
        "blank_email": int((df["email"].str.strip() == "").sum()),
        "non_numeric_or_nonpositive_quantity": int(((qty.isna()) | (qty <= 0)).sum()),
        "non_numeric_or_negative_price": int(((price.isna()) | (price < 0)).sum()),
        "duplicate_business_keys": int(df.duplicated(["order_id", "order_line_id"], keep="first").sum()),
    }


def prepare_file(path) -> bool:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df.columns = [c.strip().lower() for c in df.columns]

    missing = [c for c in COLUMNS if c not in df.columns]
    if missing:
        print(f"[FAIL] {path.name}: missing columns {missing}")
        return False

    df = df[COLUMNS]
    before = len(df)
    df = df[~(df.apply(lambda col: col.str.strip()) == "").all(axis=1)]   # fully blank rows
    df = df.drop_duplicates()                                             # exact duplicate rows
    report = {"file": path.name, "rows_in": before, "rows_out": len(df), **profile(df)}

    PREPARED_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(PREPARED_DIR / path.name, index=False)
    (REPORT_DIR / f"{path.stem}_profile.json").write_text(json.dumps(report, indent=2))
    print(f"[OK]   {path.name}: {before:,} -> {len(df):,} rows | {report}")
    return True


def main() -> int:
    state = load_state()
    files = sorted(RAW_DIR.glob("*.csv"))
    if not files:
        print("No raw files found. Run: python python/generate_sales_data.py")
        return 1
    ok = True
    for f in files:
        if state.get(f.name) == file_hash(f):
            print(f"[SKIP] {f.name}: already loaded (unchanged)")
            continue
        ok &= prepare_file(f)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
