"""Generate synthetic, deliberately messy sales data in 3 incremental batches.

Injected issues (so the pipeline has real work to do):
  - exact duplicate rows, mixed casing, stray whitespace
  - DD/MM/YYYY dates mixed with ISO dates
  - blank emails, blank order ids, zero/negative quantities
  - batch 2 re-sends 40 order lines from batch 1 with corrected quantities (late-arriving updates)
"""
import random

import numpy as np
import pandas as pd

from common import COLUMNS, RAW_DIR

random.seed(42)
np.random.seed(42)

REGIONS = [("N01", "North", "India"), ("S01", "South", "India"), ("E01", "East", "India"),
           ("W01", "West", "India"), ("C01", "Central", "India"), ("UAE", "Middle East", "UAE"),
           ("SG1", "Singapore", "Singapore"), ("UK1", "United Kingdom", "UK")]
CATEGORIES = {"Electronics": (2000, 60000), "Furniture": (1500, 40000), "Office Supplies": (50, 1500),
              "Apparel": (300, 6000), "Home Appliances": (1500, 35000)}
SEGMENTS = ["Consumer", "Corporate", "Small Business"]
CHANNELS = ["Online", "Retail Store", "Distributor", "Direct Sales"]
FIRST = ["Aarav", "Diya", "Vivaan", "Ananya", "Rohan", "Isha", "Kabir", "Meera", "Arjun", "Sara",
         "Neha", "Rahul", "Priya", "Karan", "Anjali", "Vikram", "Pooja", "Sameer", "Tanvi", "Nikhil"]
LAST = ["Sharma", "Reddy", "Patel", "Iyer", "Khan", "Gupta", "Nair", "Singh", "Das", "Mehta"]

customers = [(f"C{i:04d}", f"{random.choice(FIRST)} {random.choice(LAST)}", random.choice(SEGMENTS))
             for i in range(1, 251)]
products = []
for i in range(1, 61):
    cat = random.choice(list(CATEGORIES))
    lo, hi = CATEGORIES[cat]
    products.append((f"P{i:04d}", f"{cat} Item {i}", cat, round(random.uniform(lo, hi), 2)))


def make_batch(start: str, end: str, n_orders: int, order_prefix: str) -> pd.DataFrame:
    days = pd.date_range(start, end)
    rows = []
    for n in range(1, n_orders + 1):
        oid = f"{order_prefix}{n:06d}"
        odate = random.choice(days)
        cid, cname, seg = random.choice(customers)
        region = random.choice(REGIONS)
        channel = random.choice(CHANNELS)
        for line in range(1, random.randint(1, 4) + 1):
            pid, pname, cat, price = random.choice(products)
            rows.append({
                "order_id": oid, "order_line_id": line, "order_date": odate.strftime("%Y-%m-%d"),
                "customer_id": cid, "customer_name": cname,
                "email": f"{cname.lower().replace(' ', '.')}@example.com", "segment": seg,
                "product_id": pid, "product_name": pname, "category": cat,
                "unit_price": price, "quantity": random.randint(1, 10),
                "discount_pct": random.choice([0, 0, 0, 5, 10, 15]),
                "region_code": region[0], "region_name": region[1], "country": region[2],
                "sales_channel": channel,
            })
    return pd.DataFrame(rows, columns=COLUMNS)


def add_noise(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy().astype(object)
    n = len(df)
    idx = lambda p: np.random.choice(n, int(n * p), replace=False)  # noqa: E731

    for i in idx(0.05):
        df.iat[i, df.columns.get_loc("customer_name")] = "  " + str(df.iat[i, 4]).upper() + " "
    for i in idx(0.05):
        df.iat[i, df.columns.get_loc("category")] = str(df.iat[i, 9]).lower()
    for i in idx(0.04):
        df.iat[i, df.columns.get_loc("region_code")] = " " + str(df.iat[i, 13]).lower()
    for i in idx(0.03):
        y, m, d = str(df.iat[i, 2]).split("-")
        df.iat[i, df.columns.get_loc("order_date")] = f"{d}/{m}/{y}"
    for i in idx(0.02):
        df.iat[i, df.columns.get_loc("email")] = ""
    for i in idx(0.005):
        df.iat[i, df.columns.get_loc("quantity")] = random.choice([0, -1, "abc"])
    for i in idx(0.003):
        df.iat[i, df.columns.get_loc("order_id")] = ""
    dupes = df.sample(frac=0.03, random_state=7)
    return pd.concat([df, dupes], ignore_index=True).sample(frac=1, random_state=1).reset_index(drop=True)


def main() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    b1 = make_batch("2025-01-01", "2025-06-30", 3000, "SO1")
    b2 = make_batch("2025-07-01", "2025-09-30", 1500, "SO2")
    b3 = make_batch("2025-10-01", "2025-12-31", 1500, "SO3")

    # Late-arriving corrections: batch 2 re-sends 40 lines from batch 1 with a new quantity
    fixes = b1.sample(40, random_state=3).copy()
    fixes["quantity"] = fixes["quantity"].astype(int) + 1
    b2 = pd.concat([b2, fixes], ignore_index=True)

    for i, df in enumerate([b1, b2, b3], start=1):
        out = RAW_DIR / f"sales_batch_{i}.csv"
        add_noise(df).to_csv(out, index=False)
        print(f"wrote {out.name}: {len(df):,} rows (before noise/dupes)")


if __name__ == "__main__":
    main()
